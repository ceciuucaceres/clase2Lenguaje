
package tanque;

import java.util.Scanner;
public class Tanque {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int[][] temperaturas ={
         {15, 20, 25}, // Mañana
         {20, 25, 30}, // Tarde
         {10, 15, 20}  // Noche
        };
        System.out.print("Ingrese si esta en la mañana, tarde o noche: ");
        String momentoDia = scanner.nextLine();
        System.out.print("Ingrese la temperatura registrada: ");
        int registroTem = scanner.nextInt();

        // Obtener índice del momento del día
        int indiceMoment = obtenerIndice(momentoDia);
        if (indiceMoment != -1) { //aca se verifica si el indice de la temperatura es valida
            // Evaluación de la Temperatura
            evaluarTemperatura(temperaturas[indiceMoment], registroTem);
        } else {
            System.out.println("Momento del día no válido.");
        }

        scanner.close();
    }

    public static int obtenerIndice(String momentoDia) {
        switch (momentoDia) {
            case "mañana":
                return 0;
            case "tarde":
                return 1;
            case "noche":
                return 2;
            default:
                return -1;
        }
    }

    public static void evaluarTemperatura(int[] valoresPredeterminados, int temperaturaRegistrada) {
        if (temperaturaRegistrada < valoresPredeterminados[0]) {
            System.out.println("La temperatura del tanque es Muy Buena.");
        } else if (temperaturaRegistrada >= valoresPredeterminados[0] && temperaturaRegistrada <= valoresPredeterminados[1]) {
            System.out.println("La temperatura del tanque es Normal.");
        } else if (temperaturaRegistrada > valoresPredeterminados[2]) {
            System.out.println("La temperatura del tanque es Peligrosa.");
        }
    }
}
    
    
    

